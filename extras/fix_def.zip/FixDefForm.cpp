//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "FixDefForm.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Open1Click(TObject *Sender)
{
	if (OpenDialog1->Execute())
	{
		FName=OpenDialog1->FileName;
    RichEdit1->Lines->Clear();
    RichEdit1->Lines->LoadFromFile(FName);
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Fix1Click(TObject *Sender)
{
	int i,j;
  int ns=RichEdit1->Lines->Count;
  AnsiString s,su;
  bool ex=false;

  for (i=0;i<ns;i++) {
		s=RichEdit1->Lines->Strings[i];
    su=s.UpperCase();
    if (ex) {
    	if ((j=s.Pos("@"))>0) {
      	s.Delete(j,s.Length()-j+1);
        s=s.Trim();
        s="    _"+s+"="+s;
        RichEdit1->Lines->Strings[i]=s;
      }
    }
    else
    ex=su.Pos("EXPORT")>0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Save1Click(TObject *Sender)
{
  if (FName.Length()>0)
	{
  	SaveDialog1->FileName=FName;
    SaveDialog1->InitialDir=ExtractFileDir(FName);
		if (SaveDialog1->Execute())
  	{
    	RichEdit1->Lines->SaveToFile(FName);
      RichEdit1->Lines->Clear();
    	FName="";
  	}
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Exit1Click(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------