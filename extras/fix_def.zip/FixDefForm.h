//---------------------------------------------------------------------------
#ifndef FixDefFormH
#define FixDefFormH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include <vcl\Menus.hpp>
#include <vcl\ComCtrls.hpp>
#include <vcl\Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TMainMenu *MainMenu1;
	TMenuItem *File1;
	TMenuItem *Open1;
	TMenuItem *Fix1;
	TMenuItem *Save1;
	TMenuItem *Exit1;
	TMenuItem *N1;
	TRichEdit *RichEdit1;
	TOpenDialog *OpenDialog1;
	TSaveDialog *SaveDialog1;
	void __fastcall Open1Click(TObject *Sender);
	void __fastcall Fix1Click(TObject *Sender);
	void __fastcall Save1Click(TObject *Sender);
	void __fastcall Exit1Click(TObject *Sender);
private:	// User declarations
	AnsiString FName;
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
